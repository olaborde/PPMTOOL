# `timers` for Sketch

All the [nodejs timers](https://nodejs.org/api/timers.html) API is available.
